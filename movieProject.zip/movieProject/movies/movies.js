const _ = require("lodash");
const movie = require("../dataAccess/movieEntity");
const movieOps = require("../dataAccess/movieOps");
const BEGINSTR = "BEGIN";
const ENDSTR = "END";

async function addMovie(req, res) {
    const METHODNAME = "addMovie():: ";
    console.log(METHODNAME + BEGINSTR);
    try {
        let payload = req.body;
        await movieOps.insert(payload).then((result) => {
            console.log("Document inserted: ", result);
            res.status(201).json(result);
        }).catch((err) => {
            console.log("Error", JSON.stringify(err));
            res.status(400).json(err);
        });
    } catch (ex) {
        console.log("Error ocurred in adding a movie", JSON.stringify(ex));
        res.status(400).json(ex);
    }
    console.log(METHODNAME + ENDSTR);
}

async function addMultipleMovies(req, res) {
    const METHODNAME = "addMultipleMovies():: "
    console.log(METHODNAME + BEGINSTR);
    try {
        let movieModel = await movie.createModel();
        let payload = req.body;
        await movieOps.insertMany(payload, movieModel).then((result) => {
            console.log("Documents inserted: ", result);
            res.status(201).json(result);
        }).catch((err) => {
            console.log("Error", JSON.stringify(err));
            res.status(400).json(err);
        });
    } catch (ex) {
        console.log("Error ocurred while addding movies", JSON.stringify(ex));
        res.status(400).json(ex);
    }
    console.log(METHODNAME + ENDSTR);
}

async function getMovies(req, res) {
    const METHODNAME = "getMovies():: "
    console.log(METHODNAME + BEGINSTR);
    try {
        let query = req.query;
        let offset = parseInt(req.query.offset);
        let limit = parseInt(req.query.limit);
        let paginate = {
            skip: offset,
            limit: limit
        };
        let result = await movieOps.find(query, paginate);
        res.status(200).json(result);
    } catch (ex) {
        console.log("Error ocurred while getting movies", JSON.stringify(ex));
        res.status(400).json(ex);
    }
    console.log(METHODNAME + ENDSTR);
}

module.exports.addMovie = addMovie;
module.exports.addMultipleMovies = addMultipleMovies;
module.exports.getMovies = getMovies;
