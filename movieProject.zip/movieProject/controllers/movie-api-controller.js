const express = require("express");
const router = express.Router({mergeParams: true});
const movieModule = require("../movies/movies");

router.post("/movie", movieModule.addMovie);
router.post("/movies", movieModule.addMultipleMovies);
router.get("/movies", movieModule.getMovies);

module.exports = router;

