const movies = require("../movies/movies");
const movieOps = require("../dataAccess/movieOps");

var response = {
    responseStatus: 200,
    "status": function (status) {
        this.responseStatus = status;
        return this;
    },
    "json": function () {}
};

describe("Movie test cases", function () {
    it("should /POST a movie", async function (done) {
        var request = {};
        request.body = {
            name: "Tenet",
            year: 2020,
            director: "Christopher Nolan"
        }
        spyOn(movieOps, "insert").and.callFake(function () {
            return Promise.resolve("Success");
        });
        response.status = function (statusCode) {
            return {
                json: function () {
                    expect(statusCode).toEqual(201)
                    done()
                }
            }
        }
        await movies.addMovie(request, response);
    })

    it("should catch error in /POST a movie", async function (done) {
        var request = {};
        request.body = {
            name: "Tenet",
            year: 2020,
            director: "Christopher Nolan"
        }
        spyOn(movieOps, "insert").and.callFake(function () {
            return Promise.reject("Error");
        });
        response.status = function (statusCode) {
            return {
                json: function () {
                    expect(statusCode).toEqual(400)
                    done()
                }
            }
        }
        await movies.addMovie(request, response);
    })

    it("should /POST multiple movies", async function (done) {
        var request = {};
        request.body = {
            name: "Tenet",
            year: 2020,
            director: "Christopher Nolan"
        }
        spyOn(movieOps, "insertMany").and.callFake(function () {
            return Promise.resolve("Success");
        });
        response.status = function (statusCode) {
            return {
                json: function () {
                    expect(statusCode).toEqual(201)
                    done()
                }
            }
        }
        await movies.addMultipleMovies(request, response);
    })

    it("should catch error in /POST multiple movies", async function (done) {
        var request = {};
        request.body = {
            name: "Tenet",
            year: 2020,
            director: "Christopher Nolan"
        }
        spyOn(movieOps, "insertMany").and.callFake(function () {
            return Promise.reject("Error");
        });
        response.status = function (statusCode) {
            return {
                json: function () {
                    expect(statusCode).toEqual(400)
                    done()
                }
            }
        }
        await movies.addMultipleMovies(request, response);
    })

    it("should /GET movie(s)", async function (done) {
        var request = {};
        request.query = {
            name: "Ten",
            offset: 1,
            limit: 5
        }
        spyOn(movieOps, "find").and.callFake(function () {
            return Promise.resolve("Success");
        });
        response.status = function (statusCode) {
            return {
                json: function () {
                    expect(statusCode).toEqual(200)
                    done()
                }
            }
        }
        await movies.getMovies(request, response);
    })

    it("should catch error in /GET movie(s)", async function (done) {
        var request = {};
        request.query = {
            name: "Ten",
            offset: 1,
            limit: 5
        }
        spyOn(movieOps, "find").and.callFake(function () {
            return Promise.reject("Error");
        });
        response.status = function (statusCode) {
            return {
                json: function () {
                    expect(statusCode).toEqual(400)
                    done()
                }
            }
        }
        await movies.getMovies(request, response);
    })
})
