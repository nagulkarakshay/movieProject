const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const connection = require("../dataAccess/connection");

const movieshema = new Schema({
    name: { type: String, required: true, unique: true },
    year: { type: Number, required: false },
    director: { type: String, required: false }
});

const createModel = async function() {
    try {
        return mongoose.model("Movies", movieshema);
    } catch (ex) {
        await connection.closeConnection();
        throw new Error(ex);
    }
}

module.exports.createModel = createModel;

