const _ = require("lodash");
const movie = require("../dataAccess/movieEntity");

const insert = async (data) => {
    try {
        const movieModel = await movie.createModel();
        return new Promise((resolve, reject) => {
            movieModel.findOneAndUpdate(
                { "name": data.name },
                data,
                {
                    upsert: true, runValidators: true, returnNewDocument: true, new: true, useFindAndModify: false,
                },
                (err, rawResponse) => {
                    if (err) {
                        console.log('Error', err);
                        reject(new Error('Error in creating/updating movie'));
                    }
                    resolve(rawResponse);
                }
            );
        });
    } catch (ex) {
        throw new Error(ex);
    }
}

const insertMany = async (data, model) => {
    try {
        if (_.isEmpty(model)) {
            model = await movie.createModel();
        }
        return new Promise((resolve, reject) => {
            model.insertMany(data, (err, result) => {
                if (err) {
                    reject(err);
                } else { resolve(result); }
            });
        });
    } catch (ex) {
        throw new Error(ex);
    }
}

const find = async (query, paginate) => {
    try {
        const movieModel = await movie.createModel();
        let obj;
        if (query.name) {
            obj = {
                "name": {
                    "$regex": query.name,
                    "$options": "i"
                }
            }
        }
        const result = await movieModel.find(obj, null, paginate);
        if (_.isEmpty(result)) {
            return new Error(`Unable to find any movie with query ${query}`);
        } else {
            return result;
        }
    } catch (ex) {
        throw new Error(ex);
    }
}

module.exports.insert = insert;
module.exports.insertMany = insertMany;
module.exports.find = find;
